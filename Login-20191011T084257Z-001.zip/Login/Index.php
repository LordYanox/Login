<?php 

    $alert = '';
    session_start();
    if(!empty($_SESSION['active']))
    {
        header('location: AdminLTE/index.php');
    }else{  

    if(!empty($_POST))
    {
     if (empty($_POST['usuario'])|| empty($_POST['clave']))
     {
       $alert = "ingrese su usuario y su clave";
        }else{

            require_once "conexion.php";

            $user = mysqli_real_escape_string($conection,$_POST['usuario']);
            $pass = md5(mysqli_real_escape_string($conection,$_POST['clave']));

            $query = mysqli_query($conection,"SELECT * FROM usuario WHERE usuario = '$user' AND clave = '$pass'");

            $result = mysqli_num_rows($query);

        if($result > 0 )
        {
            $data = mysqli_fetch_array($query);
            $_SESSION['active'] = true;
            $_SESSION['idusuario'] = $data['idusuario'];
            $_SESSION['nombre'] = $data['nombre'];
            $_SESSION['correo'] = $data ['correo'];
            $_SESSION['user'] = $data ['usuario'];
            $_SESSION['rol'] = $data ['rol'];

            header('location: AdminLTE/index.php');

        }else{
        $alert = "El usuario o la clave son incorrectos";
        session_destroy();
      } 
    }
  }

}

?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Login</title>


    <!-- Owl-Carousel -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css"
        integrity="sha256-UhQQ4fxEeABh4JrcmAJ1+16id/1dnlOEVCFOxDef9Lw=" crossorigin="anonymous" />
    <link rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.min.css"
        integrity="sha256-kksNxjDRxd/5+jGurZUJd1sdR2v+ClrCl3svESBaJqw=" crossorigin="anonymous" />

    <!-- Font Awesome CDN -->
    <script src="https://kit.fontawesome.com/23412c6a8d.js"></script>

    <!-- Custom Style-->
    <link rel="stylesheet" href="./css/Style.css">
</head>

<body>

    <div class="container">
        <div class="panel">
            <div class="row">
                <div class="col liquid">
                    <h4><i class="fas fa-laptop-medical"></i></i> Medic SENA</h4>

                    <!-- Owl-Carousel -->

                    <div class="owl-carousel owl-theme">
                        <img src="./assets/undraw_doctors_hwty.svg" alt="" class="login_img">
                        <img src="./assets/undraw_doctor_kw5l.svg" alt="" class="login_img">
                        <img src="./assets/undraw_medicine_b1ol.svg" alt="" class="login_img">
                    </div>

                    <!-- /Owl-Carousel -->

                    <div class="follow">Siguenos 
                        <i class="fab fa-facebook-f"></i>
                        <i class="fab fa-twitter"></i>
                    </div>
                </div>
                <div class="col login">

                    <form action="" method="post">
                        <div class="titles">
                            <h3>Login MEDIC SENA</h3>
                        </div>
                        <div class="form-group">
                            <input name="usuario" type="text" placeholder="Usuario" class="form-input">
                            <div class="input-icon">
                                <i class="fas fa-user"></i>
                            </div>
                        </div>
                        <div class="form-group">
                            <input name="clave" type="password" placeholder="Clave" class="form-input">
                            <div class="input-icon">
                                <i class="fas fa-user-lock"></i>
                            </div>
                        </div>

                        <button type="submit" class="btn btn-login" value="INGRESAR">Ingresar</button>
                    </form>

                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js"
        integrity="sha256-pTxD+DSzIwmwhOqTFN+DB+nHjO4iAsbgfyFq5K5bcE0=" crossorigin="anonymous"></script>

    <script>
        $(document).ready(function () {

            $('.owl-carousel').owlCarousel({
                loop: true,
                autoplay: true,
                autoplayTimeout: 2000,
                autoplayHoverPause: true,
                items: 1
            });
        });
    </script>
</body>

</html>